package com.example2_1.Log.entity;

public class Log {
    
}

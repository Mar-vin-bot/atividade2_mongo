package com.exercicio2.exercicio_2.service;

public class List {

}

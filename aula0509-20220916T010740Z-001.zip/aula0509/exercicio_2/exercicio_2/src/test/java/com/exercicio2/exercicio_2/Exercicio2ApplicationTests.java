package com.exercicio2.exercicio_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercicio2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
